
import numpy as np
import matplotlib.pyplot as plt
import sys


#To get number of bands
f = open('wannier.wout','r')
for i in f:
  if "Number of Wannier Functions" in i:
    bands=int(i.split()[-2])
    break
f.close()

#End of getting number of electrons
#vbm_val=max(z[len(x)*(vbm_num-1):len(x)*vbm_num,1])
#cbm_val=min(z[len(x)*vbm_num:len(x)*(vbm_num+1),1])
#bandgap=(cbm_val-vbm_val)*1000.0 # unit:meV
#fermi = (cbm_val+vbm_val)/2 

f = open('../1-scf/pw.out','r')
for i in f:
  if "Fermi" in i:
    fermi=float(i.split()[-2])
    break
f.close()
# or manually input the Fermi energy, number of bands, and number of k points
#fermi = 13.7375

#bands = 8
#k_points = 153
f = open('wannier_band.kpt','r')
for i, line in enumerate(f):
  if i == 0:
    k_points = int(line.split()[0])
    break

f.close()

# relative to the Fermi energy
Emin = -10.0
Emax = 5.0

k_axis=np.zeros(k_points)
f = open('wannier_band.dat','r')
for i in range(k_points):
  line=f.readline()
  k_axis[i]=line.split()[0]

f.close()

#print(k_axis)

f = open('wannier_band.gnu','r')
for l in f:
  if 'set xtics' in l:
    line=l[12:-2].split(',"')
    #print(line)

high_points=[]
hp_labels=[]

for i in range(len(line)):
  if line[i][0] == "G":
    hp_labels.append("Γ")
  else:
    hp_labels.append(line[i][0])
  high_points.append(float(line[i][-7:]))

f.close()
#print(high_points)


# File with the band data
in_file = 'wannier_band.dat'

''' Load the data file into numpy. Using this command removes the blank lines
from the input file'''
data = np.loadtxt(in_file)

#Convert Ry to eV (for qe-5.4); Commnet out the following line for qe-6.1:
#data[:,1]=data[:,1]*13.6

fig = plt.figure()
ax = fig.add_subplot(111)
for axis in ['top','bottom','left','right']:
    ax.spines[axis].set_linewidth(2)


# Plot the lines corresponding to the high symmetry points
if len(high_points)>=3:
    for i in range(len(high_points)):
        ax.axvline(high_points[i],c='k',linewidth=1.5)
    #plt.text(high_points[i], Emin*1.05, hp_labels[i], fontsize=12, fontweight='bold')

##

# plot Fermi energy    
plt.axhline(c='r',linestyle='dashed',linewidth=2)
#plt.text(high_points[-1]*1.01, 0, '$E_F$',fontsize=14)

''' Now, we will use the first column of the first set of band data to define
the x axis of our plot. Then, we iterate over all the data in the second
column to plot the bands'''
i = 1
while i <= bands:
    y = data[(i-1)*k_points : i*k_points,1] - fermi
    ax.plot(k_axis,y,c='b',linewidth=2)
    i = i + 1

# Label and show the plot
#plt.suptitle('Band Structure', fontsize = 14, fontweight='bold')
ax.set_xticks(high_points)#,fontsize=fontsize)
ax.set_xticklabels(hp_labels)#,fontsize=fontsize)
ax.tick_params(labelsize=14)
#plt.xticks(high_points,hp_labels,fontsize=14)

ax.set_ylabel('Energy (eV)', fontsize=18)
ax.set_xlim(high_points[0],high_points[-1])
ax.set_ylim(Emin,Emax)

plt.savefig(sys.argv[1],dpi=300,bbox_inches='tight')
plt.show()
