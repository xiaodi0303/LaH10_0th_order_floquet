
import numpy as np
import matplotlib.pyplot as plt
import sys
import matplotlib
matplotlib.use('Agg')


Emin = -10
Emax =  5

in_file = 'bands.dat.gnu'
data = np.loadtxt(in_file)

file1 = open('pw.in', 'r')
for line in file1:
  if "K_POINTS {crystal_b}" in line:
    num_paths = int(file1.readline())
    hp_labels = []
    hp_position = [0]
    for i in range(num_paths-1):
      line = file1.readline()
      list_tmp=line.split()
      label = list_tmp[-1]
      if label == 'G':
        label = 'Γ'
      hp_labels.append(label)
      hp_position.append(int(list_tmp[3])+hp_position[i])
    break

line = file1.readline()
list_tmp=line.split()
label = list_tmp[-1]
if label == 'G':
  label = 'Γ'
hp_labels.append(label)
file1.close()

k_axis=np.unique(data[:,0])

high_points=np.zeros(len(hp_position))
j=0
for i in hp_position:
  high_points[j]=k_axis[i]
  j+=1

f = open('pw.out', 'r')

for line in f:
  if "number of k points" in line:
    num_kpoints=int(line.split()[4])
    break
f.close()

f = open('../1-scf/pw.out','r')
for i in f:
  if "Fermi" in i:
    fermi=float(i.split()[-2])
    break
f.close()

fig = plt.figure()
ax = fig.add_subplot(111)

bands = int(data[:,0].size/num_kpoints)

i=0
while i < bands:
    y = data[i*num_kpoints : (i+1)*num_kpoints,1] - fermi
    ax.plot(k_axis,y,c='b',linewidth=2)
    i = i + 1

# Plot the lines corresponding to the high symmetry points
if len(high_points)>=3:
    for i in range(len(high_points)):
        ax.axvline(high_points[i],c='k',linewidth=1.5)

# plot Fermi energy    
plt.axhline(c='r',linestyle='dashed',linewidth=2)

for axis in ['top','bottom','left','right']:
    ax.spines[axis].set_linewidth(2)

# Label and show the plot
#plt.suptitle('Band Structure', fontsize = 14, fontweight='bold')
ax.set_xticks(high_points)#,fontsize=fontsize)
ax.set_xticklabels(hp_labels)#,fontsize=fontsize)
ax.tick_params(labelsize=14)
plt.xticks(high_points,hp_labels,fontsize=14)

ax.set_ylabel('Energy (eV)', fontsize=18)
ax.set_xlim(high_points[0],high_points[-1])
ax.set_ylim(Emin,Emax)

plt.savefig(sys.argv[1],dpi=300,bbox_inches='tight')
#plt.show()

